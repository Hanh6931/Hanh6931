#!/usr/bin/env python
# coding: utf-8

# In[2]:


import speech_recognition as sr
import joblib
import numpy as np
import pandas as pd
import time
import os
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import logging
logging.basicConfig(level=logging.DEBUG)


# 优化：检查 Wi-Fi 数据集路径是否存在
DATA_PATH = 'wifi_localization.txt'

def load_wifi_data(data_path):
    """加载Wi-Fi定位数据并进行预处理"""
    if not os.path.exists(data_path):
        print(f"Error: Data file '{data_path}' not found.")
        return None

    print(f"Loading Wi-Fi localization data from {data_path}...")
    data = pd.read_csv(data_path, sep='\t', header=None)
    data.columns = [f"Signal_{i+1}" for i in range(7)] + ["Room"]
    return data

# 加载 Wi-Fi 室内定位模型和标准化器
def load_wifi_model():
    try:
        svm_wifi_model = joblib.load('svm_wifi_localization_model.pkl')
        scaler = joblib.load('scaler.pkl')
        print("Models loaded successfully.")
    except FileNotFoundError:
        print("Model files not found. Training new models...")
        svm_wifi_model, scaler = preprocess_wifi_data()  # 如果没有模型，则训练模型
    return svm_wifi_model, scaler

# 获取实时环境数据（模拟）
def get_real_time_data():
    return {
        'Temperature': np.random.uniform(15, 30),
        'Humidity': np.random.uniform(30, 80),
        'Light_Intensity': np.random.uniform(0, 1),
        'Time_of_Day': np.random.randint(0, 24),
        'User_Home': np.random.randint(0, 2),
        'Weekday': np.random.randint(0, 2),
        'User_Preference': np.random.uniform(0, 1)
    }

# 训练并预处理 Wi-Fi 定位模型
def preprocess_wifi_data():
    data = load_wifi_data(DATA_PATH)
    if data is None:
        print("No data loaded. Exiting...")
        return None, None

    X = data.drop("Room", axis=1)
    y = data["Room"]
    
    # 拆分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # 标准化数据
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # 训练SVM模型
    print("Training SVM model for Wi-Fi localization...")
    svm_wifi_model = SVC(kernel='linear', random_state=42)
    svm_wifi_model.fit(X_train_scaled, y_train)
    
    # 保存模型和标准化器
    joblib.dump(svm_wifi_model, 'svm_wifi_localization_model.pkl')
    joblib.dump(scaler, 'scaler.pkl')
    
    print(f"Training accuracy: {svm_wifi_model.score(X_test_scaled, y_test):.2f}")
    return svm_wifi_model, scaler

# 语音控制系统
def listen_to_user_command():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        print("Listening for commands...")
        recognizer.adjust_for_ambient_noise(source, duration=1)  # 调整背景噪声
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio)
        print(f"Recognized command: {command}")  # 打印识别到的命令
        return command.lower()
    except sr.UnknownValueError:
        print("Sorry, I could not understand the command.")
        return None
    except sr.RequestError as e:
        print(f"Recognition service error: {e}")
        return None

# 基于 Wi-Fi 信号预测房间
def predict_room(svm_wifi_model, scaler):
    wifi_signals = np.random.uniform(-90, -30, size=(1, 7))  # 模拟 Wi-Fi 信号
    wifi_signals_df = pd.DataFrame(wifi_signals, columns=[f"Signal_{i+1}" for i in range(7)])  # 加上列名
    wifi_signals_scaled = scaler.transform(wifi_signals_df)  # 使用带有列名的数据进行标准化
    predicted_room = svm_wifi_model.predict(wifi_signals_scaled)[0]
    return predicted_room

# 基于房间定位自动控制灯光，包括离开房间时关灯
def control_lights_based_on_room(new_room, current_room, lights):
    room_mapping = {
        1: "Bedroom",
        2: "Kitchen",
        3: "Living Room",
        4: "Bathroom"
    }
    
    # 将房间编号转换为名称
    new_room_name = room_mapping.get(new_room, None)
    current_room_name = room_mapping.get(current_room, None)
    
    if new_room_name and new_room_name != current_room_name:  # 用户进入新的房间
        if current_room_name is not None and lights[current_room_name] == 1:  # 如果当前房间的灯是开着的
            lights[current_room_name] = 0  # 关闭当前房间的灯
            print(f"User left room {current_room_name}. Turning off the light.")
        
        if lights[new_room_name] == 0:  # 如果新房间的灯是关闭的
            lights[new_room_name] = 1  # 打开新房间的灯
            print(f"User entered room {new_room_name}. Turning on the light.")
    return lights

# 控制灯光亮度（增加亮度、降低亮度）
def adjust_light_brightness(room, brightness, lights_brightness):
    if brightness == 'increase':
        lights_brightness[room] = min(lights_brightness[room] + 1, 3)  # 最大亮度为3
        print(f"Brightness increased in room {room}. Current brightness level: {lights_brightness[room]}")
    elif brightness == 'decrease':
        lights_brightness[room] = max(lights_brightness[room] - 1, 0)  # 最低亮度为0
        print(f"Brightness decreased in room {room}. Current brightness level: {lights_brightness[room]}")

# 控制特定房间的灯光开关
def control_light(state, room, lights, lights_brightness):
    if state == 'on':
        lights[room] = 1
        print(f"Turning on the light in room {room} via voice command.")
        lights_brightness[room] = 2  # 默认亮度为2
    elif state == 'off':
        lights[room] = 0
        print(f"Turning off the light in room {room} via voice command.")

# 控制窗帘
def control_curtain(state, room):
    if state == 'open':
        print(f"Opening the curtain in room {room} via voice command.")
    elif state == 'close':
        print(f"Closing the curtain in room {room} via voice command.")

# 控制空调
def control_ac(state, room):
    if state == 'on':
        print(f"Turning on the air conditioner in room {room} via voice command.")
    elif state == 'off':
        print(f"Turning off the air conditioner in room {room} via voice command.")

# 处理语音命令的功能
def process_command(command, lights, lights_brightness):
    if "turn on light" in command:
        if "bedroom" in command:
            control_light('on', "Bedroom", lights, lights_brightness)
        elif "kitchen" in command:
            control_light('on', "Kitchen", lights, lights_brightness)
    elif "turn off light" in command:
        if "bedroom" in command:
            control_light('off', "Bedroom", lights, lights_brightness)
        elif "kitchen" in command:
            control_light('off', "Kitchen", lights, lights_brightness)
    elif "brighten light" in command:
        if "bedroom" in command:
            adjust_light_brightness("Bedroom", 'increase', lights_brightness)
        elif "kitchen" in command:
            adjust_light_brightness("Kitchen", 'increase', lights_brightness)
    elif "dim light" in command:
        if "bedroom" in command:
            adjust_light_brightness("Bedroom", 'decrease', lights_brightness)
        elif "kitchen" in command:
            adjust_light_brightness("Kitchen", 'decrease', lights_brightness)
    elif "open curtain" in command:
        if "bedroom" in command:
            control_curtain('open', "Bedroom")
        elif "kitchen" in command:
            control_curtain('open', "Kitchen")
    elif "close curtain" in command:
        if "bedroom" in command:
            control_curtain('close', "Bedroom")
        elif "kitchen" in command:
            control_curtain('close', "Kitchen")
    elif "turn on ac" in command:
        if "bedroom" in command:
            control_ac('on', "Bedroom")
        elif "kitchen" in command:
            control_ac('on', "Kitchen")
    elif "turn off ac" in command:
        if "bedroom" in command:
            control_ac('off', "Bedroom")
        elif "kitchen" in command:
            control_ac('off', "Kitchen")
    else:
        print("Command not recognized or not supported.")

# 主函数：运行智能家居系统，自动开关灯并支持语音控制
def run_smart_home_system():
    svm_wifi_model, scaler = load_wifi_model()  # 加载或训练 Wi-Fi 模型
    if svm_wifi_model is None or scaler is None:
        return  # 模型未能加载或训练时退出

    current_room = None  # 当前房间初始化为空
    lights_brightness = {"Bedroom": 2, "Kitchen": 2, "Living Room": 2, "Bathroom": 2}  # 默认亮度为2
    lights = {"Bedroom": 0, "Kitchen": 0, "Living Room": 0, "Bathroom": 0}  # 0 关灯，1 开灯

    while True:
        real_time_data = get_real_time_data()
        
        # Wi-Fi 定位预测房间
        new_room = predict_room(svm_wifi_model, scaler)
        print(f"Predicted room: {new_room}, Current room: {current_room}")  # 增加调试输出
        
        if new_room != current_room:
            print(f"User moved from room {current_room} to room {new_room}.")
            
            # 自动控制灯光：离开当前房间时关闭灯，进入新房间时打开灯
            lights = control_lights_based_on_room(new_room, current_room, lights)

            # 更新当前房间
            current_room = new_room

        # 处理语音命令
        command = listen_to_user_command()
        if command:
            process_command(command, lights, lights_brightness)

        # 等待 1 秒再进行下一次检测，响应更快
        time.sleep(1)

# 运行智能家居系统
if __name__ == "__main__":
    run_smart_home_system()



# In[ ]:





# In[ ]:




